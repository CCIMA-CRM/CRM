(function($){
  $(function(){

    $('select').formSelect();

  });
})(jQuery);
